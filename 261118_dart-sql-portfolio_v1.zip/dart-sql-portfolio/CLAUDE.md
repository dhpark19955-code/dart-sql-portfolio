# CLAUDE.md - dart-sql-portfolio

SQL 포트폴리오 프로젝트. 배경과 설계는 `docs/PLAN.md`, 결과 설명은 `README.md`.

## 실행 순서 (항상 이 순서)

```bash
pip install -r requirements.txt
python scripts/build_db.py        # dart_sector.db 재생성 (기존 DB 삭제 후 빌드)
python scripts/run_queries.py     # results/*.md 재생성
```

SQL을 고쳤으면 `run_queries.py` 를 다시 돌려 `results/` 를 갱신하고, README의 수치가 바뀌면 README도 같이 고친다.

## 규칙

- 시크릿: OpenDART 키는 환경변수 `DART_API_KEY` 로만. 코드·CSV·README에 키 원문을 쓰지 않는다. `.env` 는 gitignore 대상.
- 데이터: 공개 데이터(DART·KRX·yfinance)만 사용. 사내 자료나 포지션 정보는 넣지 않는다.
- 금액 단위: DB는 백만원(`financials_annual`), 결과 표시는 십억원(`/1000.0`). 음수는 `-` 로 표기, △ 사용 금지.
- 문장 부호: em dash(—) 대신 하이픈(-).
- SQL 스타일: 각 `sql/q*.sql` 상단에 `-- Q번호. 질문 / 기법 / 주의` 주석을 유지한다 (`run_queries.py` 가 이 주석을 결과 md 머리말로 가져간다). 0 나눗셈은 `NULLIF`. 표준 SQL 우선, SQLite 전용 함수는 주석으로 표시.
- 원천 CSV(`data/raw/dart_key_accounts_fy*.csv`)는 API 응답 형태(콤마 포함 금액 문자열, 3개년 wide)를 그대로 둔다. 정제는 `sql/02_load_clean.sql` 에서만 한다.
- 새 연도 CSV를 추가하면 `scripts/build_db.py` 의 `CSV_TO_STAGING` 에 등록해야 적재된다.
- 결과 해석을 쓸 때는 사실(표 수치) / 계산(식) / 추론(해석)을 구분해 표기한다.

## 남은 작업 (우선순위 순)

1. **연도 확장**: `DART_API_KEY` 설정 후 `python scripts/fetch_dart.py 2022` → `build_db.py` 에 `dart_key_accounts_fy2022.csv` 추가 → 재빌드. `02_load_clean.sql` 의 dedup(ROW_NUMBER ... ORDER BY rcept_no DESC)이 fy2025 파일의 2023년 값과 fy2022 파일의 2022년 값을 섞지 않는지 확인 (연도가 겹치지 않으므로 문제 없어야 함).
2. **filings 테이블 추가**: OpenDART `list.json` (corp_code별, bgn_de=20230101, pblntf_ty=B 주요사항보고서)으로 `data/raw/filings.csv` 수집 → `01_schema.sql` 에 `filings(rcept_no PK, corp_code, report_nm, rcept_dt, pblntf_ty)` 추가 → 분석 쿼리 q7: 회사·연도별 주요사항보고서 건수와 주가 변동폭 JOIN.
3. **더존비즈온 주식수 보완**: `data/raw/shares_manual.csv` (stock_code, shares, as_of_date, source) 를 만들고 `02_load_clean.sql` 에서 KRX 목록에 없는 종목만 보충. 값은 FY2025 사업보고서 자본금 15,738,996,500원 / 액면가 500원 = 31,477,993주 (추정, 출처 명시). 단 주가가 없으므로 q2 NULL은 그대로 남음 - README 주의 문구 유지.
4. **README 수치 재확인**: results 재생성 후 README 3절 수치가 표와 일치하는지 검토.
5. **GitHub 배포**: 아래 명령. 레포는 새로 만들거나 `claude-code-data-portfolio` 안에 `sql/dart-sector-analysis/` 로 넣는다.

```bash
git init && git add . && git commit -m "DART x KRX sector SQL analysis - initial"
git branch -M main
git remote add origin https://github.com/<user>/dart-sql-portfolio.git
git push -u origin main
```

push 전에 `git grep -n "crtfc_key=\|DART_API_KEY=[A-Za-z0-9]"` 로 키 원문이 없는지 확인한다.

## 파일 역할 요약

| 경로 | 역할 |
|---|---|
| `scripts/fetch_dart.py` | OpenDART 다중회사 주요계정 → raw CSV (키 필요) |
| `scripts/fetch_prices.py` | yfinance 일별 주가 + KRX 주식수 → raw CSV |
| `scripts/build_db.py` | raw CSV → SQLite staging → 정제 테이블 |
| `scripts/run_queries.py` | `sql/q*.sql` 실행 → `results/*.md` |
| `sql/01_schema.sql` | 테이블 정의 |
| `sql/02_load_clean.sql` | UNPIVOT·형변환·PIVOT·중복제거·단위통일 |
| `sql/q1~q6` | 분석 쿼리 |
