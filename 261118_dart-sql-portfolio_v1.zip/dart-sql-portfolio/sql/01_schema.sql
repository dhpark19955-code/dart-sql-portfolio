-- 01_schema.sql
-- 원천(staging) 테이블과 정제된 분석용 테이블을 분리한다.
-- stg_*  : CSV를 그대로 적재 (문자열, 콤마 포함 금액 등 원형 유지)
-- 분석용 : 타입 정리·단위 통일·피벗 완료, 분석 쿼리는 이 테이블만 사용

PRAGMA foreign_keys = ON;

-- ---------- staging ----------
DROP TABLE IF EXISTS stg_companies;
CREATE TABLE stg_companies (
    corp_code      TEXT,
    stock_code     TEXT,
    corp_name      TEXT,
    corp_name_en   TEXT,
    market         TEXT,
    sector         TEXT,
    yf_ticker      TEXT,
    delisted_date  TEXT
);

DROP TABLE IF EXISTS stg_dart_key_accounts;
CREATE TABLE stg_dart_key_accounts (
    rcept_no         TEXT,
    bsns_year        TEXT,
    reprt_code       TEXT,
    corp_code        TEXT,
    stock_code       TEXT,
    fs_div           TEXT,
    sj_div           TEXT,
    account_nm       TEXT,
    thstrm_amount    TEXT,   -- 당기  (예: "1,234,567" / "-1,234" / "-")
    frmtrm_amount    TEXT,   -- 전기
    bfefrmtrm_amount TEXT,   -- 전전기
    currency         TEXT
);

DROP TABLE IF EXISTS stg_prices_daily;
CREATE TABLE stg_prices_daily (
    stock_code TEXT,
    trade_date TEXT,
    open       REAL,
    high       REAL,
    low        REAL,
    close      REAL,
    adj_close  REAL,
    volume     REAL
);

DROP TABLE IF EXISTS stg_shares_outstanding;
CREATE TABLE stg_shares_outstanding (
    stock_code  TEXT,
    shares      INTEGER,
    as_of_date  TEXT
);

-- ---------- 분석용 ----------
DROP TABLE IF EXISTS companies;
CREATE TABLE companies (
    corp_code      TEXT PRIMARY KEY,          -- DART 고유번호 (8자리)
    stock_code     TEXT NOT NULL UNIQUE,      -- 종목코드 (6자리)
    corp_name      TEXT NOT NULL,
    corp_name_en   TEXT,
    market         TEXT CHECK (market IN ('KOSPI', 'KOSDAQ')),
    sector         TEXT NOT NULL,
    delisted_date  TEXT                       -- NULL이면 상장 유지
);

-- 회사 x 회계연도 1행, 금액은 백만원(KRW mn) 단위로 통일
DROP TABLE IF EXISTS financials_annual;
CREATE TABLE financials_annual (
    corp_code        TEXT NOT NULL REFERENCES companies(corp_code),
    fiscal_year      INTEGER NOT NULL,
    fs_div           TEXT NOT NULL DEFAULT 'CFS',   -- 연결
    current_assets   INTEGER,
    total_assets     INTEGER,
    current_liab     INTEGER,
    total_liab       INTEGER,
    total_equity     INTEGER,
    revenue          INTEGER,
    op_income        INTEGER,
    net_income       INTEGER,
    source_rcept_no  TEXT,                          -- 출처 접수번호
    PRIMARY KEY (corp_code, fiscal_year, fs_div)
);

DROP TABLE IF EXISTS prices_daily;
CREATE TABLE prices_daily (
    stock_code TEXT NOT NULL REFERENCES companies(stock_code),
    trade_date TEXT NOT NULL,                 -- 'YYYY-MM-DD'
    close      REAL NOT NULL,
    adj_close  REAL,
    volume     INTEGER,
    PRIMARY KEY (stock_code, trade_date)
);
CREATE INDEX idx_prices_date ON prices_daily (trade_date);

DROP TABLE IF EXISTS shares_outstanding;
CREATE TABLE shares_outstanding (
    stock_code TEXT PRIMARY KEY REFERENCES companies(stock_code),
    shares     INTEGER NOT NULL,
    as_of_date TEXT NOT NULL
);
